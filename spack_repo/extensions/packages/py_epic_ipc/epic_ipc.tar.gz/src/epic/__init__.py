from ctypes import CDLL, POINTER, c_char, c_char_p, c_int, c_size_t, c_ubyte, c_uint, byref, c_void_p, cast, create_string_buffer, Structure, memmove
from pathlib import Path


this_dir = Path(__file__).parent
for f in this_dir.iterdir():
    if f.is_file:
        if f.name.startswith("ipc") and f.name.endswith(".so"):
            FFI = CDLL(str(f.absolute()))
            break
else:
    raise ImportError("Could not find ipc.so shared object file")
class c_shm_handle(Structure):
    _fields_ = [
        ("fd", c_int),
        ("addr", c_void_p),
        ("size", c_size_t)
    ]
posixmq_open_create = FFI.posixmq_open_create
posixmq_open_create.argtypes = [c_char_p, c_size_t, c_size_t, POINTER(c_int)]
posixmq_open_existing = FFI.posixmq_open_existing
posixmq_open_existing.argtypes = [c_char_p, POINTER(c_int), POINTER(c_size_t), POINTER(c_size_t)]
posixmq_close = FFI.posixmq_close
posixmq_close.argtypes = [c_int]
posixmq_unlink = FFI.posixmq_unlink
posixmq_unlink.argtypes = [c_char_p]
posixmq_send = FFI.posixmq_send
posixmq_send.argtypes = [c_int, c_char_p, c_size_t, c_uint]
posixmq_recv = FFI.posixmq_recv
posixmq_recv.argtypes = [c_int, c_char_p, POINTER(c_size_t), POINTER(c_uint)]
class PosixMQ:
    def __init__(
            self,
            name: str,
            queue_fd: int,
            max_queue_size,
            max_msg_size,
    ):
        self.name = name
        self.fd = queue_fd
        self.max_queue_size = max_queue_size
        self.max_msg_size = max_msg_size
        
    @classmethod
    def create(
            cls,
            name: str,
            max_queue_size: int = 10,
            max_msg_size = 4096
    ) -> "PosixMQ":
        queue_id = c_int()
        res = posixmq_open_create(
            name.encode(),
            max_msg_size,
            max_queue_size,
            byref(queue_id)
        )
        if res != 0:
            print("create failed")
        return cls(name, queue_id.value, max_queue_size, max_msg_size)

    
    @classmethod
    def open(cls, name: str) -> "PosixMQ":
        queue_id = c_int()
        max_queue_size = c_size_t()
        max_msg_size = c_size_t()
        res = posixmq_open_existing(
            name.encode(),
            byref(queue_id),
            byref(max_msg_size),
            byref(max_queue_size),
        )
        if res != 0:
            print("open failed")
        return cls(name, queue_id.value, max_queue_size.value, max_msg_size.value) 
    
    def close(self):
        posixmq_close(self.fd)

    def unlink(self):
        posixmq_unlink(self.name.encode())
        
    def send(self, data: str, prio: int):
        data_bytes = data.encode()
        res = posixmq_send(self.fd, data_bytes, len(data_bytes), prio)
        if res != 0:
            print("send failed")
    def recv(self) -> str:
        buf_out = create_string_buffer(self.max_msg_size)
        size_inout = c_size_t(self.max_msg_size)
        priority_out = c_uint()
        res = posixmq_recv(
            self.fd,
            buf_out,
            size_inout,
            priority_out
        )
        if res != 0:
            print("recv failed")
        return buf_out.value[:size_inout.value].decode()


posixshm_create = FFI.posixshm_create
posixshm_create.argtypes = [c_char_p, c_size_t]
posixshm_create.restype = POINTER(c_shm_handle)
posixshm_open = FFI.posixshm_open
posixshm_open.argtypes = [c_char_p, c_size_t]
posixshm_open.restype = POINTER(c_shm_handle)
posixshm_close = FFI.posixshm_close
posixshm_close.argtypes = [POINTER(c_shm_handle)]
posixshm_unlink = FFI.posixshm_unlink
posixshm_unlink.argtypes = [c_char_p]

class PosixShm:
    def __init__(
            self,
            name: str,
            handle_ptr: c_shm_handle
    ):
        self.name = name
        self.handle_ptr = handle_ptr
        self._buf = None
        self._mv = None

    @property
    def fd(self):
        return self.handle_ptr.contents.fd

    @property
    def addr(self):
        return self.handle_ptr.contents.addr
    
    @property 
    def size(self):
        return self.handle_ptr.contents.size
    
    @classmethod
    def create(cls, name: str, size: int) -> "PosixShm":
        '''
        Create a shared memory region with `name` and `size`
        '''
        handle_ptr = posixshm_create(name.encode(), size)
        return cls(name, handle_ptr)
    
    @classmethod
    def open(cls, name: str, size: int) -> "PosixShm":
        handle_ptr = posixshm_open(name.encode(), size)
        return cls(name, handle_ptr)

    def unlink(self):
        posixshm_unlink(self.name.encode())

    def read(self) -> memoryview:
        if self._mv is None:
            buf_type = c_char * self.size
            self._buf = buf_type.from_address(cast(self.addr, c_void_p).value)
            self._mv = memoryview(self._buf)
        return self._mv
    
    def write(self, new_data: bytes):
        if len(new_data) > self.size:
            raise ValueError(f"Data length {len(new_data)} exceeds shared memory size {self.size}")

        memmove(self.addr, new_data, len(new_data))
    
            
    def close(self):
        posixshm_close(self.handle_ptr)

